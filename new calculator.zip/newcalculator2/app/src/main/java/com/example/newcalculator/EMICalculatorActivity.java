package com.example.newcalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EMICalculatorActivity extends AppCompatActivity {
    private EditText principalEditText;
    private EditText interestRateEditText;
    private EditText tenureEditText;
    private Button calculateButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emi_calculator);

        // Initialize views
        principalEditText = findViewById(R.id.principalEditText);
        interestRateEditText = findViewById(R.id.interestRateEditText);
        tenureEditText = findViewById(R.id.tenureEditText);
        calculateButton = findViewById(R.id.calculateButton);
        resultTextView = findViewById(R.id.resultTextView);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateEMI();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void calculateEMI() {
        // Validate and parse input
        String principalStr = principalEditText.getText().toString().trim();
        String interestRateStr = interestRateEditText.getText().toString().trim();
        String tenureStr = tenureEditText.getText().toString().trim();

        try {
            double principal = Double.parseDouble(principalStr);
            double interestRate = Double.parseDouble(interestRateStr);
            double tenure = Double.parseDouble(tenureStr);

            // EMI Calculation
            double monthlyRate = interestRate / 12 / 100;
            double totalMonths = tenure * 12;

            double emi = principal * monthlyRate *
                    (Math.pow(1 + monthlyRate, totalMonths)) /
                    (Math.pow(1 + monthlyRate, totalMonths) - 1);

            double totalPayment = emi * totalMonths;
            double totalInterest = totalPayment - principal;

            // Format and display results
            String resultText = String.format(
                    "EMI Calculation Results:\n\n" +
                            "Monthly EMI: ₹%.2f\n" +
                            "Total Payment: ₹%.2f\n" +
                            "Total Interest: ₹%.2f",
                    emi, totalPayment, totalInterest
            );

            resultTextView.setText(resultText);

        } catch (NumberFormatException e) {
            resultTextView.setText("Please enter valid numbers");
        }
    }
}